import { Stack } from 'expo-router';

export default function RootLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index" />
      <Stack.Screen name="register" />
      <Stack.Screen name="dashboard" />
      <Stack.Screen name="delivery-details" />
      <Stack.Screen name="customer-dashboard" />
       <Stack.Screen name="settings" />
    </Stack>
  );
}